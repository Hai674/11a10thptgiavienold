"use client";

import { useState } from "react";
import { MessageSquare, Send } from "lucide-react";

interface Entry {
  id: string;
  name: string;
  message: string;
  createdAt: string;
}

const INITIAL: Entry[] = [
  {
    id: "1",
    name: "Bạn cũ",
    message: "Nhớ lớp 11A10 quá! Mong sớm được gặp lại mọi người.",
    createdAt: new Date().toISOString(),
  },
];

export default function GuestbookPage() {
  const [entries, setEntries] = useState<Entry[]>(INITIAL);
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !message.trim()) return;
    const newEntry: Entry = {
      id: Date.now().toString(),
      name: name.trim(),
      message: message.trim(),
      createdAt: new Date().toISOString(),
    };
    setEntries((prev) => [newEntry, ...prev]);
    setName("");
    setMessage("");
  }

  return (
    <div className="mx-auto max-w-2xl px-4 py-10 sm:px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Sổ lưu bút</h1>
        <p className="mt-2 text-muted-foreground">
          Viết lời nhắn gửi đến lớp 11A10
        </p>
      </div>

      <form
        onSubmit={handleSubmit}
        className="mb-10 rounded-2xl border border-border bg-card p-5 shadow-sm"
      >
        <div className="space-y-4">
          <div>
            <label className="mb-1.5 block text-sm font-medium">Tên của bạn</label>
            <input
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Nguyễn Văn A"
              className="w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none ring-primary focus:ring-2"
              required
            />
          </div>
          <div>
            <label className="mb-1.5 block text-sm font-medium">Lời nhắn</label>
            <textarea
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              placeholder="Viết gì đó thật chân thành..."
              rows={3}
              className="w-full resize-none rounded-xl border border-border bg-background px-3 py-2.5 text-sm outline-none ring-primary focus:ring-2"
              required
            />
          </div>
          <button
            type="submit"
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground transition hover:opacity-90"
          >
            <Send className="h-4 w-4" />
            Gửi lời nhắn
          </button>
        </div>
      </form>

      <div className="space-y-4">
        {entries.map((entry) => (
          <div
            key={entry.id}
            className="rounded-2xl border border-border bg-card p-5"
          >
            <div className="mb-2 flex items-center gap-2">
              <MessageSquare className="h-4 w-4 text-primary" />
              <span className="font-semibold">{entry.name}</span>
              <span className="text-xs text-muted-foreground">
                {new Date(entry.createdAt).toLocaleDateString("vi-VN")}
              </span>
            </div>
            <p className="text-sm leading-relaxed text-muted-foreground">
              {entry.message}
            </p>
          </div>
        ))}
      </div>
    </div>
  );
}
