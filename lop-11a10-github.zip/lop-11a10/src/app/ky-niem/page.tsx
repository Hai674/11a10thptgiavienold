import { MOCK_MEMORIES } from "@/lib/constants";
import { Calendar, User } from "lucide-react";

export default function MemoriesPage() {
  const sorted = [...MOCK_MEMORIES].sort(
    (a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()
  );

  return (
    <div className="mx-auto max-w-3xl px-4 py-10 sm:px-6">
      <div className="mb-10">
        <h1 className="text-3xl font-bold tracking-tight">Kỷ niệm</h1>
        <p className="mt-2 text-muted-foreground">
          Timeline những khoảnh khắc đáng nhớ của lớp 11A10
        </p>
      </div>

      <div className="relative space-y-8 before:absolute before:left-[11px] before:top-2 before:h-[calc(100%-16px)] before:w-0.5 before:bg-border">
        {sorted.map((memory) => (
          <article key={memory.id} className="relative pl-10">
            <div className="absolute left-0 top-1.5 h-6 w-6 rounded-full border-4 border-background bg-primary" />
            <div className="rounded-2xl border border-border bg-card p-5 shadow-sm">
              <div className="mb-2 flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
                <span className="inline-flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  {new Date(memory.date).toLocaleDateString("vi-VN", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </span>
                <span className="inline-flex items-center gap-1">
                  <User className="h-3.5 w-3.5" />
                  {memory.authorName}
                </span>
              </div>
              <h2 className="text-lg font-semibold text-foreground">
                {memory.title}
              </h2>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {memory.content}
              </p>
            </div>
          </article>
        ))}
      </div>

      {sorted.length === 0 && (
        <div className="py-20 text-center text-muted-foreground">
          Chưa có kỷ niệm nào. Hãy là người đầu tiên!
        </div>
      )}
    </div>
  );
}
