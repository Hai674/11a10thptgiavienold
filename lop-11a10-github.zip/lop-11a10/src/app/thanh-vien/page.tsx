"use client";

import { useMemo, useState } from "react";
import { Search, User } from "lucide-react";
import { MOCK_MEMBERS } from "@/lib/constants";
import type { Member } from "@/types";
import { cn } from "@/lib/utils";

export default function MembersPage() {
  const [search, setSearch] = useState("");
  const [teamFilter, setTeamFilter] = useState<string>("all");
  const [genderFilter, setGenderFilter] = useState<string>("all");

  const filtered = useMemo(() => {
    return MOCK_MEMBERS.filter((m) => {
      const matchSearch =
        m.fullName.toLowerCase().includes(search.toLowerCase()) ||
        (m.nickname?.toLowerCase().includes(search.toLowerCase()) ?? false);
      const matchTeam =
        teamFilter === "all" || String(m.team) === teamFilter;
      const matchGender =
        genderFilter === "all" || m.gender === genderFilter;
      return matchSearch && matchTeam && matchGender;
    });
  }, [search, teamFilter, genderFilter]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Thành viên</h1>
        <p className="mt-2 text-muted-foreground">
          Danh sách {MOCK_MEMBERS.length} thành viên lớp 11A10
        </p>
      </div>

      {/* Filters */}
      <div className="mb-8 flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <input
            type="text"
            placeholder="Tìm theo tên hoặc nickname..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full rounded-xl border border-border bg-card py-2.5 pl-10 pr-4 text-sm outline-none ring-primary focus:ring-2"
          />
        </div>
        <select
          value={teamFilter}
          onChange={(e) => setTeamFilter(e.target.value)}
          className="rounded-xl border border-border bg-card px-3 py-2.5 text-sm outline-none"
        >
          <option value="all">Tất cả tổ</option>
          <option value="1">Tổ 1</option>
          <option value="2">Tổ 2</option>
          <option value="3">Tổ 3</option>
        </select>
        <select
          value={genderFilter}
          onChange={(e) => setGenderFilter(e.target.value)}
          className="rounded-xl border border-border bg-card px-3 py-2.5 text-sm outline-none"
        >
          <option value="all">Tất cả</option>
          <option value="Nam">Nam</option>
          <option value="Nữ">Nữ</option>
        </select>
      </div>

      {/* Grid */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {filtered.map((member) => (
          <MemberCard key={member.id} member={member} />
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="py-20 text-center text-muted-foreground">
          Không tìm thấy thành viên nào.
        </div>
      )}
    </div>
  );
}

function MemberCard({ member }: { member: Member }) {
  return (
    <div className="group rounded-2xl border border-border bg-card p-5 shadow-sm transition hover:shadow-md">
      <div className="flex items-start gap-4">
        <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-blue-500 to-amber-400 text-lg font-bold text-white">
          {member.fullName.charAt(0)}
        </div>
        <div className="min-w-0 flex-1">
          <h3 className="truncate font-semibold text-foreground">
            {member.fullName}
          </h3>
          {member.nickname && (
            <p className="text-sm text-muted-foreground">@{member.nickname}</p>
          )}
          <div className="mt-2 flex flex-wrap gap-1.5">
            <span className="rounded-full bg-blue-100 px-2.5 py-0.5 text-xs font-medium text-blue-700 dark:bg-blue-950 dark:text-blue-300">
              {member.role}
            </span>
            {member.team && (
              <span className="rounded-full bg-secondary px-2.5 py-0.5 text-xs text-muted-foreground">
                Tổ {member.team}
              </span>
            )}
          </div>
        </div>
      </div>
      {member.quote && (
        <p className="mt-4 line-clamp-2 text-sm italic text-muted-foreground">
          “{member.quote}”
        </p>
      )}
      {member.birthDate && (
        <p className="mt-3 flex items-center gap-1.5 text-xs text-muted-foreground">
          <User className="h-3.5 w-3.5" />
          {new Date(member.birthDate).toLocaleDateString("vi-VN")}
        </p>
      )}
    </div>
  );
}
