import Link from "next/link";
import { Users, Camera, Heart, ArrowRight, Sparkles } from "lucide-react";
import { MOCK_MEMBERS, MOCK_MEMORIES } from "@/lib/constants";

export default function HomePage() {
  const stats = [
    {
      label: "Thành viên",
      value: MOCK_MEMBERS.length,
      icon: Users,
      href: "/thanh-vien",
    },
    {
      label: "Kỷ niệm",
      value: MOCK_MEMORIES.length,
      icon: Heart,
      href: "/ky-niem",
    },
    {
      label: "Ảnh & Video",
      value: "∞",
      icon: Camera,
      href: "/anh-video",
    },
  ];

  return (
    <div className="relative overflow-hidden">
      {/* Hero */}
      <section className="relative mx-auto max-w-6xl px-4 pb-16 pt-12 sm:px-6 sm:pt-20">
        <div className="absolute -left-32 -top-32 h-72 w-72 rounded-full bg-blue-400/20 blur-3xl dark:bg-blue-600/10" />
        <div className="absolute -right-32 top-20 h-72 w-72 rounded-full bg-amber-300/30 blur-3xl dark:bg-amber-500/10" />

        <div className="relative text-center">
          <div className="mb-6 inline-flex items-center gap-2 rounded-full border border-border bg-card/80 px-4 py-1.5 text-sm text-muted-foreground backdrop-blur">
            <Sparkles className="h-4 w-4 text-amber-500" />
            Kỷ niệm thanh xuân
          </div>

          <h1 className="text-4xl font-bold tracking-tight text-foreground sm:text-5xl md:text-6xl">
            Lớp{" "}
            <span className="bg-gradient-to-r from-blue-600 to-amber-500 bg-clip-text text-transparent">
              11A10
            </span>
          </h1>

          <p className="mx-auto mt-5 max-w-2xl text-base text-muted-foreground sm:text-lg">
            Nơi lưu giữ những khoảnh khắc đẹp nhất của thanh xuân chúng ta.
            Cùng nhau viết nên câu chuyện của lớp 11A10.
          </p>

          <div className="mt-8 flex flex-wrap items-center justify-center gap-3">
            <Link
              href="/thanh-vien"
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/25 transition hover:bg-primary/90"
            >
              Xem thành viên
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/ky-niem"
              className="inline-flex items-center gap-2 rounded-xl border border-border bg-card px-6 py-3 text-sm font-semibold text-foreground transition hover:bg-secondary"
            >
              Xem kỷ niệm
            </Link>
          </div>
        </div>
      </section>

      {/* Stats */}
      <section className="mx-auto max-w-6xl px-4 pb-20 sm:px-6">
        <div className="grid gap-4 sm:grid-cols-3">
          {stats.map((stat) => (
            <Link
              key={stat.label}
              href={stat.href}
              className="group rounded-2xl border border-border bg-card p-6 shadow-sm transition hover:border-primary/40 hover:shadow-md"
            >
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{stat.label}</p>
                  <p className="mt-1 text-3xl font-bold tracking-tight text-foreground">
                    {stat.value}
                  </p>
                </div>
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 text-primary transition group-hover:bg-primary group-hover:text-primary-foreground">
                  <stat.icon className="h-6 w-6" />
                </div>
              </div>
            </Link>
          ))}
        </div>
      </section>

      {/* Recent memories preview */}
      <section className="border-t border-border bg-secondary/30 py-16">
        <div className="mx-auto max-w-6xl px-4 sm:px-6">
          <div className="mb-8 flex items-end justify-between">
            <div>
              <h2 className="text-2xl font-bold tracking-tight">
                Kỷ niệm gần đây
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Những khoảnh khắc đáng nhớ nhất
              </p>
            </div>
            <Link
              href="/ky-niem"
              className="hidden text-sm font-medium text-primary hover:underline sm:inline-flex"
            >
              Xem tất cả →
            </Link>
          </div>

          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {MOCK_MEMORIES.slice(0, 3).map((memory) => (
              <article
                key={memory.id}
                className="rounded-2xl border border-border bg-card p-5 shadow-sm"
              >
                <time className="text-xs text-muted-foreground">
                  {new Date(memory.date).toLocaleDateString("vi-VN", {
                    day: "numeric",
                    month: "long",
                    year: "numeric",
                  })}
                </time>
                <h3 className="mt-2 font-semibold text-foreground">
                  {memory.title}
                </h3>
                <p className="mt-2 line-clamp-2 text-sm text-muted-foreground">
                  {memory.content}
                </p>
                <p className="mt-3 text-xs text-muted-foreground">
                  — {memory.authorName}
                </p>
              </article>
            ))}
          </div>

          <div className="mt-6 text-center sm:hidden">
            <Link
              href="/ky-niem"
              className="text-sm font-medium text-primary hover:underline"
            >
              Xem tất cả kỷ niệm →
            </Link>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-6xl px-4 py-16 sm:px-6">
        <div className="rounded-3xl bg-gradient-to-br from-blue-600 to-blue-700 px-6 py-12 text-center text-white shadow-xl sm:px-12">
          <h2 className="text-2xl font-bold sm:text-3xl">
            Bạn là thành viên 11A10?
          </h2>
          <p className="mx-auto mt-3 max-w-lg text-blue-100">
            Hãy để lại lời nhắn trong sổ lưu bút hoặc chia sẻ kỷ niệm của bạn
            với cả lớp.
          </p>
          <div className="mt-6 flex flex-wrap justify-center gap-3">
            <Link
              href="/guestbook"
              className="rounded-xl bg-white px-6 py-3 text-sm font-semibold text-blue-700 transition hover:bg-blue-50"
            >
              Viết sổ lưu bút
            </Link>
            <Link
              href="/ky-niem"
              className="rounded-xl border border-white/30 bg-white/10 px-6 py-3 text-sm font-semibold text-white backdrop-blur transition hover:bg-white/20"
            >
              Thêm kỷ niệm
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
