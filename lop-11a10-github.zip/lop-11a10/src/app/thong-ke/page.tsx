import { MapPin, Users, Heart, Camera } from "lucide-react";
import { MOCK_MEMBERS, MOCK_MEMORIES } from "@/lib/constants";

export default function StatsPage() {
  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Thống kê truy cập</h1>
        <p className="mt-2 text-muted-foreground">
          Tổng quan hoạt động và vị trí truy cập website
        </p>
      </div>

      <div className="mb-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {[
          { label: "Thành viên", value: MOCK_MEMBERS.length, icon: Users },
          { label: "Kỷ niệm", value: MOCK_MEMORIES.length, icon: Heart },
          { label: "Ảnh", value: 24, icon: Camera },
          { label: "Lượt truy cập", value: "—", icon: MapPin },
        ].map((s) => (
          <div
            key={s.label}
            className="rounded-2xl border border-border bg-card p-5 shadow-sm"
          >
            <div className="flex items-center gap-3">
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 text-primary">
                <s.icon className="h-5 w-5" />
              </div>
              <div>
                <p className="text-2xl font-bold">{s.value}</p>
                <p className="text-xs text-muted-foreground">{s.label}</p>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Map placeholder */}
      <div className="rounded-2xl border border-border bg-card p-6">
        <h2 className="mb-4 flex items-center gap-2 text-lg font-semibold">
          <MapPin className="h-5 w-5 text-primary" />
          Bản đồ truy cập
        </h2>
        <div className="flex h-64 items-center justify-center rounded-xl bg-secondary/50 text-sm text-muted-foreground">
          <div className="text-center">
            <p>Bản đồ Leaflet + OpenStreetMap</p>
            <p className="mt-1 text-xs">
              (Kết nối GPS tracking + Supabase để hiển thị vị trí thật)
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
