import { ImageIcon } from "lucide-react";

export default function GalleryPage() {
  // Placeholder grid
  const placeholders = Array.from({ length: 12 }, (_, i) => i + 1);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10 sm:px-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold tracking-tight">Ảnh & Video</h1>
        <p className="mt-2 text-muted-foreground">
          Bộ sưu tập khoảnh khắc của lớp 11A10
        </p>
      </div>

      <div className="columns-1 gap-4 sm:columns-2 lg:columns-3">
        {placeholders.map((i) => (
          <div
            key={i}
            className="mb-4 break-inside-avoid overflow-hidden rounded-2xl border border-border bg-secondary/50"
          >
            <div
              className="flex items-center justify-center bg-gradient-to-br from-blue-100 to-amber-100 dark:from-slate-800 dark:to-slate-700"
              style={{ height: `${180 + (i % 4) * 40}px` }}
            >
              <div className="flex flex-col items-center gap-2 text-muted-foreground">
                <ImageIcon className="h-8 w-8 opacity-50" />
                <span className="text-xs">Ảnh {i}</span>
              </div>
            </div>
          </div>
        ))}
      </div>

      <p className="mt-10 text-center text-sm text-muted-foreground">
        Kết nối Supabase Storage để upload ảnh thật.
      </p>
    </div>
  );
}
